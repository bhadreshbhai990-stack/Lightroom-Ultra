package com.example.lrlite

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.pow
import androidx.compose.ui.graphics.ColorFilter as ComposeColorFilter
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix

/** All adjustments, each roughly in -1..1 (exposure in stops: -2..2). */
data class Adjust(
    val exposure: Float = 0f, val contrast: Float = 0f, val brightness: Float = 0f,
    val saturation: Float = 0f, val temperature: Float = 0f, val tint: Float = 0f,
    val mono: Boolean = false, val rotation: Int = 0
)

private val presets = linkedMapOf(
    "Original" to Adjust(),
    "Vivid" to Adjust(contrast = 0.15f, saturation = 0.4f),
    "Warm" to Adjust(temperature = 0.4f, exposure = 0.1f),
    "Cool" to Adjust(temperature = -0.4f, tint = 0.1f),
    "Matte" to Adjust(contrast = -0.2f, brightness = 0.06f, saturation = -0.2f),
    "Drama" to Adjust(contrast = 0.4f, exposure = -0.2f, saturation = -0.1f),
    "B&W" to Adjust(mono = true, contrast = 0.2f)
)

private val tools = listOf("Exposure", "Contrast", "Brightness", "Saturation", "Temp", "Tint")

fun Adjust.colorMatrix(): ColorMatrix {
    val m = ColorMatrix()
    val e = 2f.pow(exposure)
    m.postConcat(ColorMatrix(floatArrayOf(e,0f,0f,0f,0f, 0f,e,0f,0f,0f, 0f,0f,e,0f,0f, 0f,0f,0f,1f,0f)))
    val c = 1f + contrast; val t = (1f - c) * 127.5f + brightness * 255f
    m.postConcat(ColorMatrix(floatArrayOf(c,0f,0f,0f,t, 0f,c,0f,0f,t, 0f,0f,c,0f,t, 0f,0f,0f,1f,0f)))
    val sat = ColorMatrix(); sat.setSaturation(if (mono) 0f else 1f + saturation); m.postConcat(sat)
    val r = 1f + 0.3f * temperature; val b = 1f - 0.3f * temperature; val g = 1f - 0.2f * tint
    m.postConcat(ColorMatrix(floatArrayOf(r,0f,0f,0f,0f, 0f,g,0f,0f,0f, 0f,0f,b,0f,0f, 0f,0f,0f,1f,0f)))
    return m
}

fun loadBitmap(ctx: Context, uri: Uri, maxSide: Int = 3000): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}

fun exportBitmap(ctx: Context, src: Bitmap, a: Adjust): Boolean {
    val rot = Matrix().apply { postRotate(a.rotation.toFloat()) }
    val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, rot, true)
    val out = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(a.colorMatrix()) }
    Canvas(out).drawBitmap(rotated, 0f, 0f, paint)
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "LRLite_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LightroomLite")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
    ctx.contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    return true
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { Editor() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Editor() {
    val ctx = LocalContext.current
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var adj by remember { mutableStateOf(Adjust()) }
    var tool by remember { mutableStateOf("Exposure") }
    var status by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { bitmap = loadBitmap(ctx, it); adj = Adjust() }
    }

    fun value(): Float = when (tool) {
        "Exposure" -> adj.exposure / 2f; "Contrast" -> adj.contrast; "Brightness" -> adj.brightness
        "Saturation" -> adj.saturation; "Temp" -> adj.temperature; else -> adj.tint
    }
    fun setValue(v: Float) {
        adj = when (tool) {
            "Exposure" -> adj.copy(exposure = v * 2f); "Contrast" -> adj.copy(contrast = v)
            "Brightness" -> adj.copy(brightness = v); "Saturation" -> adj.copy(saturation = v)
            "Temp" -> adj.copy(temperature = v); else -> adj.copy(tint = v)
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { picker.launch("image/*") }) { Text("Open") }
            OutlinedButton(onClick = { adj = Adjust() }, enabled = bitmap != null) { Text("Reset") }
            OutlinedButton(onClick = { adj = adj.copy(rotation = (adj.rotation + 90) % 360) }, enabled = bitmap != null) { Text("Rotate") }
            Spacer(Modifier.weight(1f))
            Button(onClick = {
                status = if (exportBitmap(ctx, bitmap!!, adj)) "Saved to Pictures/LightroomLite" else "Export failed"
            }, enabled = bitmap != null) { Text("Export") }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp).clipToBounds(), contentAlignment = Alignment.Center) {
            val bmp = bitmap
            if (bmp == null) Text("Photo open karo")
            else Image(
                bitmap = bmp.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                colorFilter = ComposeColorFilter.colorMatrix(ComposeColorMatrix(adj.colorMatrix().array)),
                modifier = Modifier.fillMaxSize().graphicsLayer { rotationZ = adj.rotation.toFloat() }
            )
        }
        if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(presets.keys.toList()) { name ->
                AssistChip(onClick = { adj = presets[name]!!.copy(rotation = adj.rotation) }, label = { Text(name) })
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
            items(tools) { t -> FilterChip(selected = tool == t, onClick = { tool = t }, label = { Text(t) }) }
        }
        Slider(value = value(), onValueChange = { setValue(it) }, valueRange = -1f..1f, enabled = bitmap != null)
    }
}
