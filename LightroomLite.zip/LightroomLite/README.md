# Lightroom Lite (Android, Kotlin + Jetpack Compose)

Open in Android Studio (Koala+) -> Sync -> Run.

Features: open photo, Exposure / Contrast / Brightness / Saturation / Temp / Tint sliders,
7 presets, B&W, rotate, reset, export JPEG to Pictures/LightroomLite.

Ideas to extend: highlights/shadows (per-pixel or RenderScript/AGSL shader), crop, curves,
vignette/grain, before/after, undo stack, RAW via LibRaw, masks.
